CREATE TRIGGER STUD_INSERT
BEFORE INSERT
  ON STUDENTS
FOR EACH ROW
  BEGIN
  SELECT stud_seq.NEXTVAL
  INTO   :new.stud_id
  FROM   dual;

  SELECT to_date('01.09.'||EXTRACT(year FROM :new.entrance_date), 'DD.MM.YYYY')
  INTO   :new.entrance_date
  FROM   dual;

END;
/
